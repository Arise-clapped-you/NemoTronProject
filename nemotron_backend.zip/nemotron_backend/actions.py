def comfort_check():
    print("✨ Comfort Bot activated: Turning on LED light and playing soft tone.")

def alert_caregiver():
    print("🚨 ALERT: No response from patient. Sending message to caregiver (mock API).")
