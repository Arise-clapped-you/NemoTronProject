import os
import requests
import json
import base64
from nemotron_agent import initialize_nemotron_agent

# --- VLM IMAGE ENCODING (Reused from previous step) ---
def encode_image(image_path):
    """Encodes a local image file into a Base64 string."""
    with open(image_path, "rb") as image_file:
        return f"data:image/png;base64,{base64.b64encode(image_file.read()).decode('utf-8')}"

# --- VLM EXTRACTION CALL (The 'Perception' Stage) ---
def extract_data_from_image(image_path: str, prompt: str) -> str:
    """
    Performs the initial VLM call to extract structured data from the invoice image.
    """
    NVIDIA_API_KEY = os.environ.get("NVIDIA_API_KEY")
    if not NVIDIA_API_KEY:
        raise ValueError("NVIDIA_API_KEY not found in environment variables.")

    NIM_API_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
    VLM_MODEL_NAME = "nvidia/nemotron-nano-12b-v2-vl"

    multimodal_content = [
        {"type": "image_url", "image_url": {"url": encode_image(image_path)}},
        {"type": "text", "text": prompt}
    ]

    headers = {"Authorization": f"Bearer {NVIDIA_API_KEY}", "Accept": "application/json"}
    payload = {
        "model": VLM_MODEL_NAME,
        "messages": [{"role": "user", "content": multimodal_content}],
        "max_tokens": 1024,
        "temperature": 0.0
    }

    print(f"\n[STEP 1: PERCEPTION] Sending invoice image to Nemotron VLM for data extraction...")
    response = requests.post(NIM_API_URL, headers=headers, json=payload, timeout=120)

    if response.status_code == 200:
        data = response.json()
        text_response = data['choices'][0]['message']['content']
        print("[STEP 1 SUCCESS] VLM extracted data.")
        return text_response
    else:
        raise Exception(f"VLM Extraction Error (Status Code {response.status_code}): {response.text}")


# --- Main Application Logic ---
if __name__ == "__main__":
    # ⚠️ IMPORTANT: CHANGE THIS PATH TO YOUR ACTUAL INVOICE/RECEIPT IMAGE FILE
    # The image file must contain an amount and a currency (e.g., £50.00, €100)
    INVOICE_IMAGE_PATH = "receipt.png"
    
    # 1. Define the Extraction Prompt (VLM Stage)
    extraction_prompt = (
        "Analyze the uploaded invoice image. Identify the vendor name, the total amount, "
        "and the 3-letter currency code (e.g., 'GBP', 'EUR'). Return only a single JSON object. "
        "Format: { 'Vendor': 'Vendor Name', 'Source_Amount': 123.45, 'Source_Currency': 'CUR' }"
    )

    try:
        # Step 1: VLM extracts structured data from the image
        extracted_data_json = extract_data_from_image(INVOICE_IMAGE_PATH, extraction_prompt)
        print(f"\n--- VLM Extracted JSON ---\n{extracted_data_json}\n--------------------------")
        
        # Step 2: LLM Agent performs multi-step reasoning and tool-calling
        agent_executor = initialize_nemotron_agent()
        
        print("\n[STEP 2: ACTION] Feeding extracted data to the Nemotron Agent for Conversion and Logging...")
        
        # The agent's input is the structured data from the VLM, not the raw image.
        agent_input = (
            f"The invoice data has been extracted as follows: {extracted_data_json}. "
            f"Please perform the full multi-step workflow now: "
            f"1. Convert the currency to USD using the tool. "
            f"2. Calculate the final USD total. "
            f"3. Log the full transaction details (including the calculated USD total) using the other tool. "
            f"4. Report the final success message."
        )

        final_result = agent_executor.invoke({"input": agent_input})
        
        print("\n=============================================")
        print("✅ AGENT WORKFLOW COMPLETE")
        print(f"Final Agent Output: {final_result['output']}")
        print("=============================================")

    except Exception as e:
        print(f"\n🔴 Fatal Error in Workflow: {e}")