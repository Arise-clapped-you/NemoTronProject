import os
import requests
import json
from dotenv import load_dotenv

# Note: API key is not strictly needed for a local, unauthenticated endpoint, 
# but we keep the structure for consistency if you eventually secure it.
load_dotenv()
API_KEY = os.getenv("NVIDIA_API_KEY")

# --- CORRECTED LOCAL ENDPOINT ---
# Target the local endpoint found in your curl command
url = "http://0.0.0.0:8000/v1/chat/completions"

# Headers needed for the request
headers = {
    "accept": "application/json",
    "Content-Type": "application/json",
    # If your local service requires authentication, uncomment and set this:
    # "Authorization": f"Bearer {API_KEY}", 
}

# --- PAYLOAD FORMATTED FOR MULTIMODAL CONTENT ---
payload = {
    "temperature": 0.0,
    "top_p": 1.0,
    "model": "nvidia/nemotron-nano-12b-v2-vl",
    "messages": [
        {
            "role": "user",
            "content": [
                { 
                    "type": "image_url", 
                    "image_url": { "url": "https://assets.ngc.nvidia.com/products/api-catalog/llama-cosmos-nemotron-8b-instruct/performance.png" } 
                },
                { 
                    "type": "text", 
                    "text": "For MOE Switch XXL training what is speed of H100 over A100 and H100 with NVLink over A100?" 
                }
            ]
        }
    ]
}

print(f"🔄 Sending Multimodal request to local endpoint: {url}...")

# Use requests.post
# IMPORTANT: Since this is an HTTP endpoint, we set verify=False (or omit it) 
# and ensure we are using the 'http' protocol in the URL.
try:
    response = requests.post(url, headers=headers, json=payload, timeout=120)

    if response.status_code == 200:
        print("✅ Nemotron responded successfully (Local service test):")
        data = response.json()
        if 'choices' in data and data['choices']:
            # Extract the actual text response
            print(data['choices'][0]['message']['content'])
        else:
            print(json.dumps(data, indent=2))
    else:
        print(f"❌ Error {response.status_code}: Local Nemotron service reported an error.")
        print("Response Text:", response.text)

except requests.exceptions.ConnectionError:
    print("❌ Connection Error: Is your local Nemotron service running on http://0.0.0.0:8000?")
    print("Ensure you have started the service (e.g., via Docker or the NeMo Toolkit).")
except Exception as e:
    print(f"An unexpected error occurred: {e}")