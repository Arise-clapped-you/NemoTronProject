import os
from langchain_nvidia_ai_endpoints import ChatNVIDIA
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from actions import all_tools # Import your tools

# --- Configuration ---
# The model supports the modern tool-calling capability
AGENT_MODEL_NAME = "nvidia/nemotron-nano-12b-v2-vl"

def initialize_nemotron_agent() -> AgentExecutor:
    """Initializes and configures the Nemotron Agent for multi-step workflow (v1.x style)."""
    
    # 1. Define the LLM (API Key is read automatically from the 'NVIDIA_API_KEY')
    llm = ChatNVIDIA(
        model=AGENT_MODEL_NAME,
        temperature=0.0 # Keep temperature low for reliable tool-calling
    )

    # 2. Define the System Prompt
    system_prompt = (
        "You are an expert financial processing agent. Your task is to process incoming invoice data. "
        "You MUST follow a strict multi-step workflow: "
        "1. **Analyze** the input to identify the 'Source Currency' and 'Amount'. "
        "2. **Convert:** If the 'Source Currency' is NOT USD, you MUST call the `get_currency_exchange_rate` tool. "
        "3. **Calculate:** Use the rate to calculate the final 'USD_Total' amount. "
        "4. **Log:** Call the `log_transaction_to_db` tool with ALL collected and calculated data. "
        "5. **Final Response:** After logging, summarize the extracted and converted data for the user."
    )

    # 3. Define the Agent Prompt Template (Modern v1.x)
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            MessagesPlaceholder(variable_name="agent_scratchpad"), # Required for agent internal thought process
            ("human", "{input}"),
        ]
    )

    # 4. Create the Tool-Calling Agent
    agent = create_tool_calling_agent(llm, all_tools, prompt)

    # 5. Create the Executor (The orchestrator)
    agent_executor = AgentExecutor(
        agent=agent, 
        tools=all_tools, 
        verbose=True, # Show the agent's thought process and tool calls
        handle_parsing_errors=True # Robustness
    )
    
    return agent_executor