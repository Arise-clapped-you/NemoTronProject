import os
from openai import OpenAI

# 1. Set your API Key
# It is recommended to set this as an environment variable for security
# For this quick test, replace the placeholder with your actual key (nvapi-...)
NVIDIA_API_KEY = "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" 

# 2. Configure the client to use NVIDIA's endpoint
client = OpenAI(
    base_url="https://integrate.api.nvidia.com/v1",
    api_key=NVIDIA_API_KEY,
)

# 3. Define the prompt and model (using Llama 3.1 Nemotron 70B Instruct as an example)
model_name = "nvidia/nemotron-nano-12b-v2-vl"

print(f"Sending request to {model_name}...")

# 4. Make the chat completion request
completion = client.chat.completions.create(
    model=model_name,
    messages=[
        {"role": "user", "content": "Explain the importance of virtual environments in Python in one paragraph."},
    ],
    temperature=0.2, # Lower temperature for focused response
)

# 5. Print the result
response_text = completion.choices[0].message.content
print("\n--- Nemotron Response ---")
print(response_text)
print("-------------------------\n")