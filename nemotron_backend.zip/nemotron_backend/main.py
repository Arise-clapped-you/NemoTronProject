from fastapi import FastAPI
from sensors import simulate_motion_sensor
from state_manager import start_monitoring

app = FastAPI(title="Nemotron Patient Monitor")

@app.on_event("startup")
async def startup_event():
    print("System booting up...")
    start_monitoring()   # Start background monitor

@app.get("/")
def read_root():
    return {"status": "Nemotron Backend is running"}

@app.get("/command")
def handle_command(cmd: str):
    if cmd.lower() == "monitor the patient network":
        simulate_motion_sensor()   # start simulated motion updates
        return {"message": "Nemotron has started monitoring the patient network"}
    else:
        return {"message": "Unknown command"}
