import asyncio
import time
from state_manager import register_motion

def simulate_motion_sensor():
    """Simulates patient movement updates."""
    print("Motion sensor activated...")
    register_motion(time.time())  # register initial motion

    async def monitor_loop():
        while True:
            await asyncio.sleep(30)  # check every 30 seconds
            # Here you could read a real sensor or randomize movement
            # For now, we simulate 'no motion' by doing nothing

    asyncio.create_task(monitor_loop())
