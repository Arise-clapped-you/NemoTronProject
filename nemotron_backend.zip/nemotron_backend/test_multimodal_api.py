import os
import requests
import json
import base64

# --- 1. Utility Function to Prepare Image Data ---
def encode_image(image_path):
    """Encodes a local image file into a Base64 string."""
    with open(image_path, "rb") as image_file:
        # The VLM expects a data URI scheme prefix for base64 encoded images
        return f"data:image/png;base64,{base64.b64encode(image_file.read()).decode('utf-8')}"

# --- 2. API Configuration ---
NVIDIA_API_KEY = os.environ.get("NVIDIA_API_KEY") # Ensure this is set in your .env
NIM_API_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
# **NOTE: We are using the VLM model ID now**
VLM_MODEL_NAME = "nvidia/nemotron-nano-12b-v2-vl"

# --- 3. Multimodal API Call ---
def query_vlm_agent(prompt: str, image_path: str):
    # Check for API Key
    if not NVIDIA_API_KEY:
        print("Error: NVIDIA_API_KEY not found in environment variables.")
        return

    # Prepare multimodal content array
    multimodal_content = [
        # 1. Image Content
        {
            "type": "image_url",
            # We are using the Base64 utility function defined above
            "image_url": {"url": encode_image(image_path)}
        },
        # 2. Text Prompt
        {
            "type": "text",
            "text": prompt
        }
    ]

    headers = {
        "Authorization": f"Bearer {NVIDIA_API_KEY}",
        "Accept": "application/json"
    }

    payload = {
        "model": VLM_MODEL_NAME,
        "messages": [
            {
                "role": "user",
                "content": multimodal_content
            }
        ],
        "max_tokens": 1024,
    }

    try:
        print(f"Sending request to {VLM_MODEL_NAME} with image and prompt...")
        response = requests.post(NIM_API_URL, headers=headers, json=payload, timeout=120)

        if response.status_code == 200:
            data = response.json()
            # Extract the actual text response from the VLM
            text_response = data['choices'][0]['message']['content']
            print("\n--- Nemotron VLM Response ---")
            print(text_response)
            print("-----------------------------")
        else:
            print(f"Error (Status Code {response.status_code}): {response.text}")

    except requests.exceptions.ConnectionError:
        print("Connection Error: Check your network connection or API URL.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# --- 4. Example Usage ---
if __name__ == "__main__":
    # ⚠️ ACTION REQUIRED: Replace 'receipt.png' with the actual path to an invoice or receipt image.
    example_image_path = "receipt.png"
    example_prompt = "From the uploaded image, what is the vendor name, the total amount, and the date of the transaction? Put the data in a JSON format."
    
    # 💡 IMPORTANT: You must place an image file (e.g., 'receipt.png') in the same directory as this script.
    
    query_vlm_agent(example_prompt, example_image_path)