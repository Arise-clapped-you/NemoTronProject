import requests
import os
from dotenv import load_dotenv

load_dotenv()
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")

def reason_no_motion():
    """Ask Nemotron to decide next step after no motion detected."""
    url = "https://api.nvidia.com/nim/v1/models/nvidia/llama-3.1-nemotron-70b-instruct"
    headers = {
        "Authorization": f"Bearer {NVIDIA_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "messages": [
            {"role": "system", "content": "You are a healthcare assistant AI responsible for patient safety."},
            {"role": "user", "content": "The motion bot reports no movement for 10 minutes. What should be done next? Respond in JSON format."}
        ]
    }

    response = requests.post(url, json=payload, headers=headers)
    return response.json()
