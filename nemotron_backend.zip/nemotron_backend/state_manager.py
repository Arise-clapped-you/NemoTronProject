import time
import asyncio
from nemotron_agent import reason_no_motion
from actions import comfort_check, alert_caregiver

last_motion_time = None

def register_motion(timestamp):
    global last_motion_time
    last_motion_time = timestamp

def start_monitoring():
    asyncio.create_task(monitor_state())

async def monitor_state():
    global last_motion_time
    while True:
        await asyncio.sleep(60)
        if last_motion_time is None:
            continue

        elapsed = time.time() - last_motion_time
        if elapsed > 600:  # 10 minutes
            print("⚠️ No motion detected for 10 minutes.")
            decision = reason_no_motion()
            print("Nemotron decided:", decision)

            if "comfort" in str(decision).lower():
                comfort_check()
            elif "alert" in str(decision).lower():
                alert_caregiver()
            else:
                print("No clear action returned.")
