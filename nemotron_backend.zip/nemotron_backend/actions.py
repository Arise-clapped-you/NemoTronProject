from langchain.tools import tool
from typing import Union

# --- Tool 1: Currency Conversion API (Mocked) ---
@tool
def get_currency_exchange_rate(source_currency: str) -> str:
    """
    Fetches the current exchange rate to convert the given source currency to USD.
    The source_currency must be a 3-letter uppercase code (e.g., 'EUR', 'GBP', 'CAD').
    Returns a string containing the exchange rate for 1 unit of the source currency in USD.
    """
    source_currency = source_currency.upper()
    
    # --- MOCKED DATA for demonstration. Replace with a real API call later. ---
    mock_rates = {
        "EUR": 1.07,  # 1 EUR = 1.07 USD
        "GBP": 1.25,  # 1 GBP = 1.25 USD
        "CAD": 0.73,  # 1 CAD = 0.73 USD
        "USD": 1.00   # 1 USD = 1.00 USD
    }
    # --------------------------------------------------------------------------

    if source_currency in mock_rates:
        rate = mock_rates[source_currency]
        return f"SUCCESS: The current exchange rate for 1 {source_currency} is {rate} USD."
    else:
        return f"ERROR: Currency code {source_currency} not recognized or rate is unavailable. Assume 1.00 for simulation."

# --- Tool 2: Transaction Logging (Mocked) ---
@tool
def log_transaction_to_db(transaction_data: str) -> str:
    """
    Logs the final, processed transaction data into the central financial database.
    Input must be a single string containing the extracted vendor, amount, date, and final USD total.
    """
    # In a real app, this would involve a connection pool and a SQL INSERT statement.
    print(f"\n[SYSTEM ACTION: DATABASE LOG] Attempting to log data...")
    print(f"Data received for logging: {transaction_data}")
    
    # Simple check for required keywords to confirm successful "logging"
    if "USD_Total" in transaction_data and "Vendor" in transaction_data:
        return "SUCCESS: Transaction successfully logged to the database. Ready for next step."
    else:
        return "FAILURE: Data missing key fields (Vendor or USD_Total). Logging aborted."

# List of all available tools for the agent
all_tools = [get_currency_exchange_rate, log_transaction_to_db]
